here are the deliverable for the project , 
Tb_FINAL is the testbench
mux, registers & comparateur are file i used for componants
FINAL_CODE is the main code

transcript is the modelsim transcript i inputed to obtain the wave in waveproject2

there also is the schematic from vivado , the implementation file and synthesis file into one text file called VIVADO.txt

in order to put in modelsim, compile all the vhd files and do the command vsim FINAL_CODE &
